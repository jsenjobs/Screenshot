exports.shop = require('./mongo/template.schema').shop;
exports.goods = require('./mongo/template.schema').goods;