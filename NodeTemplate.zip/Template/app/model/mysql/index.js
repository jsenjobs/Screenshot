/*
module.exports = function(db, cb) {
	db.load('./template.schema', (err) => {
		return cb();
	})
}
*/

module.exports = {
	'person': require('./template.schema').person
}




