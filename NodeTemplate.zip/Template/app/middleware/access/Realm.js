let PrincipalCollection = require('./Subject').PrincipalCollection



exports.Realm = class {
	constructor() {
	}

	// need impl
	doGetAuthorizationInfo(principal) {
		// return AuthorizationInfo
	}
}