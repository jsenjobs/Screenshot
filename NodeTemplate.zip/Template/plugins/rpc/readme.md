# Node json rpc framework （beta）

该文件夹下的文件实现将rpc 函数调用转换成fetch格式的http调用
