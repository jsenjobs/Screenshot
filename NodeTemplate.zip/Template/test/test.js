let path = require('path');

require('../app/conf/env').boot(path.resolve('./etc'));
require('./log4jConfig').set();

var boot = require('../server').boot;
var shutdown = require('../server').shutdown;
var port = require('../server').port;
var superagent = require('superagent');
var expect = require('expect.js');

describe('server', function () {
	before(function() {
		boot();
	});

describe('getRank', function() {
	it('should respond to GET', function(done) {
		superagent.post('http://localhost:'+port+'/verify').send().end(function(err, res){
			let json = res.body;
			expect(res.status).to.equal(200);
			expect(json.code).to.equal(0);
			done();
		})
	});
})

after(function() {
	shutdown();
})
})