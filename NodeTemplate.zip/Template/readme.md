## ECS root@120.25.217.56

#### TravisCI PM2 express [mocha expect superagent](app test) [grunt](auto app test) [webpack](部署前预处理，打包，未实现)

git pull
git push -u origin master
ssh_config 持续部署（Travis ssh需求)
修改架构



测试Grunt（Gruntfile.js）
测试TravisCI（YAML）
测试

#ssh
ssh 直接执行命令
环境变量会从 /etc/bash.bashrc 或 ~/.bashrc中找

### 参考
node webpack: http://www.thinksaas.cn/topics/0/606/606564.html